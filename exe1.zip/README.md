# big-data-analysis-course
This repo includes:
- Setup environment script - for creating a vm with pyspark
- Home work in big data analysis course (questions & solutions)


excercises:
exe1:
	-	data:
		https://www.kaggle.com/qwikfix/amazon-recommendation-dataset/data
		downloaded in vm as: Reviews.csv
	-	excercise:
		https://mama.mta.ac.il/pluginfile.php/546358/mod_resource/content/1/Big-data-analytics-targil1.pdf
		downloaded as: Big-data-analytics-targil1.pdf
